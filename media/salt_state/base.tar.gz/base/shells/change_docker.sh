systemctl stop docker
mkdir -p /data/docker
scp -cp /var/lib/docker/* /data/docker/
chmod 777 -R /data/docker
mv /var/lib/docker /var/lib/docker-`date +%s`
grep dockerroot /etc/group
if [ $? = 0 ]
	then
	groupadd -g 3003 docker
	gpasswd -a zhjkj dockerroot
	gpasswd -a zhjkj docker
fi
ln -s /data/docker /var/lib/docker
sudo mkdir -p /etc/docker
sudo tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": ["https://3ksoxp7c.mirror.aliyuncs.com"]
}
EOF
sudo systemctl daemon-reload
sudo systemctl restart docker
systemctl enable docker
