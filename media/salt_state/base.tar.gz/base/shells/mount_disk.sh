new_partition(){
fdisk  /dev/$1 << EOF
n
p
1

wq
EOF
}


disks=$(lsblk -d |grep -c disk)
if [[ ${disks} -gt  1 ]]; then
    for i in `seq ${disks}`
    do
        nums=$(expr ${i} + 1)
        disk_name=$(lsblk -d|grep disk| sed -n  "${nums}p" |awk '{print $1}')
        
        if [  -n "${disk_name}" ] ;then
            flag=$(df -h |grep -c ${disk_name})
            if [[ ${flag} == 0 ]] ; then
                echo "/dev/${disk_name}1  /data${i} ext4    defaults    0  0" 
                new_partition
                mkfs.ext4 /dev/${disk_name}1 
                cp /etc/fstab /tmp/fstab
                mkdir -p /data
                echo "/dev/${disk_name}1  /data ext4    defaults    0  0" >> /etc/fstab
                ln -s /data1 /data
                mount -a
            fi
        fi
    done
fi

