mkdir -p /data/logs/{nexus,redis,jenkins,mongodb,monitor,elk,elasticsearch,zookeeper,resin,git,zabbix,nginx,mysql,php,dubbo,tomcat,apache,redmine,java}
mkdir -p /data/{.trash,backup,server,software,jdk,tmp,docker}
mkdir -p /data/ci/{war,update,bak,docker}

SIZE=`free -m|grep Swap|awk '{print $2}'`
if [ $SIZE = 0 ]
then
	fallocate -l 4G /mnt/swap
	mkswap /mnt/swap
	grep -q swap /etc/fstab
	[ $? -ne 0 ] && scp -pr /etc/fstab /tmp/fstab_bak;echo "/mnt/swap none swap sw 0 0" >> /etc/fstab;swapon /mnt/swap
fi

echo 'export HISTTIMEFORMAT="%F %T `whoami` "' >> /etc/profile


#### ufw

systemctl enable ufw

ufw enable << EOF
y
EOF

ufw allow 80/tcp
ufw allow 443/tcp
ufw allow from 10.161.238.151
ufw allow from 115.29.198.51
ufw allow from 10.161.235.59
ufw allow from 114.215.208.75
ufw allow from 120.76.121.184
ufw allow from 119.3.18.83
ufw allow from 119.3.0.53
ufw allow from 183.6.132.26
ufw allow in on lo
ufw allow out on lo

chmod +x /etc/rc.local
echo 'chmod 777 -R /data/docker' >> /etc/rc.local
echo '/sbin/iptables-restore  /etc/iptables-script' >> /etc/rc.local
